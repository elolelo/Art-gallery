import React, {useEffect, useState, useReducer, useRef} from "react";
import LazyLoadedObjectListComponent from "./components/LazyLoadedObjectListComponent";
import "./App.css";
import { useSpring, animated } from 'react-spring'
import { ReactComponent as Loading } from './loading.svg';
import { appReducer, SET_KEYWORD, SET_RESULT, DEFAULT_SEARCH_RESULT, INITIAL_STATE,RESET } from './AppReducer';
import {Landing} from './Landing';
import ImageSlider from "./components/ImageSlider";
import DetailOverlay from "./components/MuseumObjectDetailComponent";
import {data} from './data'

function App() {

  const [timeoutToken, setTimeoutToken] = useState(null);
  const [detailOverlayItem, setDetailOverlayItem] = useState(null);
  const pauseTimer = useRef(false);

  const [appState, dispatch] = useReducer(
    appReducer,
    INITIAL_STATE
  );

  const setSearchResultAction = result => {
    dispatch({ type: SET_RESULT, payload: result });
  };

  const setKeywordAction = result => {

    dispatch({ type: SET_KEYWORD, payload: result });
  };

  /**
   * creates a "buffer" when user is typing a keyword to prevent multiple calls
   * @param {*} keyword
   */
  const setKeywordDebounced = keyword => {

    clearTimeout(timeoutToken);
    if(keyword === ""){
      dispatch({
        type:"RESET"
      })
    }else{
      var token = setTimeout(() => setKeywordAction(keyword), 400);
      setTimeoutToken(token);

    }
  };

  const chunk = (arr, size) =>
    Array.from({ length: Math.ceil(arr.length / size) }, (v, i) =>
      arr.slice(i * size, i * size + size)
    );

  const { keyword, isLoading, searchResult } = appState;

  useEffect(() => {

    const abortController = new AbortController(); // this is used to cancel ongoing fetch requests when user updates the keyword to make sure we only run relavant queries

    // if(!keyword){
    //   dispatch(INITIAL_STATE)
    // }

    const fetchData = async () => {
     
      //  TODO: add a while loop that will automatically show sliding images until a search keyword is inputted
     //
      if (keyword)
        // setSearchResultAction(DEFAULT_SEARCH_RESULT);

        try {
          var res = await fetch(
            `https://collectionapi.metmuseum.org/public/collection/v1/search?q=${keyword}`,
            {
              method: "GET",
              signal: abortController.signal,
              cache: "force-cache",
            }
          );

          var response = await res.json();

          if (!response.objectIDs)
            setSearchResultAction(DEFAULT_SEARCH_RESULT);
          else
            setSearchResultAction(response);

        } catch (err) {
          if (err.name === "AbortError") {
            console.log("Fetch aborted 👀");
            console.dir(err);
          } else {
            console.error("Error occured", err);
          }
        }
    };

    fetchData();

    return function cleanup() {
      abortController.abort();
    };
  }, [keyword]);

  const fadeInProps = useSpring({ opacity: 1, from: { opacity: 0 } })
  const titleAnimateProps = useSpring({ width: 450, config: { duration: 800 }, from: { width: 0 } })

  const removeOverlay = () => {
        setDetailOverlayItem(null);
        pauseTimer.current = false;
  }

const getGallery = ()=>{
  if(isLoading === "start"){
   
    return (
        <>
            <ImageSlider slides={data} setDetailOverlayItem={setDetailOverlayItem} pauseTimer={pauseTimer.current}/>
          {detailOverlayItem && <DetailOverlay item={detailOverlayItem} closeModal={() => removeOverlay()}/>}
        </>
    );
  }

  if(isLoading === "loading"){
 
    return <Loading/>
  }
  if(isLoading === "complete"){
  
    return  (
      <>
      <ResultsCaption style={fadeInProps} total={searchResult.total} keyword={keyword} />
      <div >
        { // break the results into chuncks of 200 items so that we can optimize performance by assigning
          // intersection observer to items in each chunk based on current scroll position at any given time
          chunk(searchResult.objectIDs, 200).map(ids =>
            <LazyLoadedObjectListComponent key={ids[0]} data={ids} />
          )}
      </div>
    </>
    )
  }
}

  return (
    <animated.div style={fadeInProps} className="App">
      <animated.h1 style={titleAnimateProps}> 🖼️ Art Museum </animated.h1>
      <animated.p style={titleAnimateProps}> Enjoy the slideshow or search below: </animated.p>
      <input
        type="search"
        placeholder="Enter any artwork type"
        onChange={e => setKeywordDebounced(e.target.value)}
        ref={input => input && input.focus()}
        aria-label="search term"
      />
      {getGallery()}
      
    </animated.div>
  );
}

const ResultsCaption = ({ total, keyword, ...props }) => keyword ?
  <animated.span className="Search-Caption" {...props}>{total + ` results for: ` + keyword}</animated.span> : null;

export default App;