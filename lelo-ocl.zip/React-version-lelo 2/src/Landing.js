import React, { useState, useEffect, useRef } from 'react';
import './App.css';
import BIRDS from 'vanta/dist/vanta.birds.min';
import {
  Link,
} from "react-router-dom";
import  App from './App'

function Button({children}) {
  return <button className="button">{children}</button>;
}

const Landing = (props) => {
  const [vantaEffect, setVantaEffect] = useState(null)
  const myRef = useRef(null)
  useEffect(() => {
    if (!vantaEffect) {
      setVantaEffect(BIRDS({
        el: myRef.current
      }))
    }
    return () => {
      if (vantaEffect) vantaEffect.destroy()
    }
  }, [vantaEffect])
  return (

      <div ref={myRef} className="main">

        <div>
          <Link to="/app">
            <Button>Visit Gallery Now</Button>
          </Link>
        </div>

      </div>

  )
}


export default Landing;